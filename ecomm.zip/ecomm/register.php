<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'db-updated.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $username = trim($_POST['username']);
        $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
        $password = $_POST['password'];

        if (empty($username) || empty($password) || !$email) {
            throw new Exception('All fields are required and must be valid');
        }

        // Check if username or email already exists
        $checkStmt = $conn->prepare("SELECT id FROM " . USERS_TABLE . " WHERE email = ? OR username = ?");
        $checkStmt->bind_param("ss", $email, $username);
        $checkStmt->execute();
        
        if ($checkStmt->get_result()->num_rows > 0) {
            throw new Exception('User already exists');
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO " . USERS_TABLE . " (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);
        
        if (!$stmt->execute()) {
            throw new Exception('Registration failed: ' . $stmt->error);
        }

        // Auto-login after registration
        $userId = $conn->insert_id;
        session_regenerate_id(true);
        
        $_SESSION = [
            'user_id' => $userId,
            'username' => $username,
            'logged_in' => true,
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT']
        ];

        echo json_encode([
            'message' => 'Registration successful',
            'user' => [
                'id' => $userId,
                'username' => $username
            ]
        ]);

    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['message' => $e->getMessage()]);
    } finally {
        if (isset($checkStmt)) $checkStmt->close();
        if (isset($stmt)) $stmt->close();
        $conn->close();
    }
}
?>
