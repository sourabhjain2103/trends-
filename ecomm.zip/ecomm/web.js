let cart = JSON.parse(localStorage.getItem("cart")) || [];
let cartTotal = parseFloat(localStorage.getItem("cartTotal")) || 0;

function updateCartCount() {
    document.getElementById("cart-count").textContent = cart.length;
}

function addToCart(itemName, itemPrice) {
    let existingItem = cart.find(item => item.name === itemName);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ name: itemName, price: itemPrice, quantity: 1 });
    }
    cartTotal += itemPrice;
    saveCart();
    updateCartCount();
    showNotification(`${itemName} added to cart!`);
}

function showNotification(message) {
    let notification = document.createElement("div");
    notification.classList.add("cart-notification");
    notification.innerText = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

function updateCart() {
    let cartList = document.getElementById("cart-items");
    let totalElement = document.getElementById("cart-total");
    if (!cartList || !totalElement) return;
    cartList.innerHTML = "";
    cart.forEach((item, index) => {
        let row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.name}</td>
            <td>$${item.price.toFixed(2)}</td>
            <td>
                <button onclick="changeQuantity(${index}, -1)">-</button>
                ${item.quantity}
                <button onclick="changeQuantity(${index}, 1)">+</button>
            </td>
            <td>$${(item.price * item.quantity).toFixed(2)}</td>
            <td><button onclick="removeFromCart(${index})">Remove</button></td>
        `;
        cartList.appendChild(row);
    });
    totalElement.textContent = cartTotal.toFixed(2);
}

function changeQuantity(index, delta) {
    if (cart[index].quantity + delta > 0) {
        cart[index].quantity += delta;
        cartTotal += cart[index].price * delta;
    } else {
        cartTotal -= cart[index].price * cart[index].quantity;
        cart.splice(index, 1);
    }
    saveCart();
    updateCart();
    updateCartCount();
}

function removeFromCart(index) {
    cartTotal -= cart[index].price * cart[index].quantity;
    cart.splice(index, 1);
    saveCart();
    updateCart();
    updateCartCount();
}

function saveCart() {
    localStorage.setItem("cart", JSON.stringify(cart));
    localStorage.setItem("cartTotal", cartTotal.toFixed(2));
}

function filterProducts() {
    let category = document.getElementById("category-filter").value;
    let products = document.querySelectorAll(".crd");
    products.forEach(product => {
        product.style.display = category === "all" || product.dataset.category === category ? "block" : "none";
    });
}

function addToWishlist(itemName, itemPrice) {
    let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
    wishlist.push({ name: itemName, price: itemPrice });
    localStorage.setItem("wishlist", JSON.stringify(wishlist));
    alert("Added to wishlist!");
}

window.onload = function() {
    updateCartCount();
    updateCart();
};
// Voice recognition setup
let recognition;
try {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        document.getElementById("search-bar").value = transcript;
        searchProducts();
        updateVoiceStatus("Voice search complete", "success");
    };

    recognition.onerror = function(event) {
        updateVoiceStatus("Error: " + event.error, "error");
    };

    recognition.onend = function() {
        document.getElementById("voice-search-btn").innerHTML = '<i class="fas fa-microphone"></i>';
    };
} catch(e) {
    console.error("Speech recognition not supported", e);
}

function updateVoiceStatus(message, type) {
    const statusElement = document.getElementById("voice-status");
    statusElement.textContent = message;
    statusElement.className = type;
    setTimeout(() => statusElement.className = "hidden", 3000);
}

function toggleVoiceSearch() {
    const searchBar = document.getElementById("search-bar");
    const voiceBtn = document.getElementById("voice-search-btn");
    
    if (!recognition) {
        updateVoiceStatus("Voice search not supported in your browser", "error");
        return;
    }

    try {
        if (recognition && recognition.running) {
            recognition.stop();
            voiceBtn.innerHTML = '<i class="fas fa-microphone"></i>';
            updateVoiceStatus("Voice search stopped", "info");
        } else {
            recognition.start();
            voiceBtn.innerHTML = '<i class="fas fa-microphone-slash"></i>';
            updateVoiceStatus("Listening... Speak now", "info");
            searchBar.focus();
        }
    } catch(e) {
        updateVoiceStatus("Error starting voice search", "error");
    }
}

// Initialize voice search button
document.addEventListener('DOMContentLoaded', function() {
    const voiceBtn = document.getElementById("voice-search-btn");
    if (voiceBtn) {
        voiceBtn.addEventListener('click', toggleVoiceSearch);
    }
});

function searchProducts() {
    const query = document.getElementById("search-bar").value.toLowerCase();
    const products = document.querySelectorAll(".crd");
    
    products.forEach(product => {
        const productName = product.querySelector("h2").textContent.toLowerCase();
        product.style.display = productName.includes(query) ? "block" : "none";
    });
}
