<?php
session_start();
require_once 'db.php';

// Admin authentication check
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle order status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $order_id);
    $stmt->execute();
    $stmt->close();
}

// Fetch orders with user details
$query = "SELECT o.*, u.username, u.email 
          FROM orders o
          JOIN users u ON o.user_id = u.id
          ORDER BY o.created_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="web.css">
</head>
<body>
    <div class="container">
        <h2>Manage Orders</h2>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = $result->fetch_assoc()): 
                    $items = json_decode($order['items'], true);
                ?>
                <tr>
                    <td><?= $order['id'] ?></td>
                    <td>
                        <?= htmlspecialchars($order['username']) ?><br>
                        <?= htmlspecialchars($order['email']) ?>
                    </td>
                    <td><?= date('M j, Y', strtotime($order['created_at'])) ?></td>
                    <td>
                        <?php foreach ($items as $item): ?>
                            <?= htmlspecialchars($item['name']) ?> (x<?= $item['quantity'] ?>)<br>
                        <?php endforeach; ?>
                    </td>
                    <td>$<?= number_format($order['total'], 2) ?></td>
                    <td>
                        <form method="POST" class="status-form">
                            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                            <select name="status" onchange="this.form.submit()">
                                <?php foreach (['pending', 'processing', 'shipped', 'delivered', 'cancelled'] as $status): ?>
                                    <option value="<?= $status ?>" <?= $order['status'] === $status ? 'selected' : '' ?>>
                                        <?= ucfirst($status) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="hidden" name="update_status" value="1">
                        </form>
                    </td>
                    <td>
                        <a href="view_order.php?id=<?= $order['id'] ?>" class="btn">View</a>
                        <a href="delete_order.php?id=<?= $order['id'] ?>" class="btn danger" 
                           onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
