<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'db.php'; // Include the database connection

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $email = $data['email'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid email format.']);
        exit;
    }

    // Email subject and message
    $subject = "Order Confirmation";
    $message = "Thank you for your order! Your payment was successful.";

    // Send email
    if (mail($email, $subject, $message)) {
        // Log email to database
        $stmt = $conn->prepare("INSERT INTO emails (email, status) VALUES (?, ?)");
        $status = 'sent';
        if ($stmt) {
            $stmt->bind_param("ss", $email, $status);
            $stmt->execute();
            $stmt->close();
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $conn->error]);
            exit;
        }

        echo json_encode(['status' => 'success', 'message' => 'Email sent successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Email sending failed.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}

$conn->close();
?>
