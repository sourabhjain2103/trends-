
<?php
$host = 'localhost';
$db = 'ecommerce'; // Your database name
$user = 'root'; // Default XAMPP MySQL username
$pass = ''; // Default XAMPP MySQL password (usually empty). Change this if you have set a password.

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>