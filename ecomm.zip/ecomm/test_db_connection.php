<?php
include 'db.php'; // Include the database connection

if ($conn) {
    echo "Database connection successful!";
} else {
    echo "Database connection failed!";
}

$conn->close();
?>
