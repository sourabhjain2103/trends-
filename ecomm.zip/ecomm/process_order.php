<?php
session_start();
require_once 'db-updated.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(['error' => 'Unauthorized']));
}

// Get input data
$data = json_decode(file_get_contents('php://input'), true);
$user_id = $_SESSION['user_id'];

try {
    // Begin transaction
    $conn->begin_transaction();

    // Prepare order data
    $items = json_encode($data['items']);
    $subtotal = $data['subtotal'];
    $tax = $data['tax'] ?? 0.00;
    $shipping = $data['shipping'] ?? 0.00;
    $total = $subtotal + $tax + $shipping;
    $payment_method = $data['payment_method'] ?? 'card';
    $status = ($payment_method === 'cod') ? 'pending' : 'processing';

    // Insert order
    $stmt = $conn->prepare("
        INSERT INTO orders (
            user_id, 
            items, 
            subtotal, 
            tax, 
            shipping, 
            total, 
            payment_method,
            status,
            shipping_address,
            billing_address
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->bind_param(
        "isddddssss", 
        $user_id,
        $items,
        $subtotal,
        $tax,
        $shipping,
        $total,
        $payment_method,
        $status,
        $data['shipping_address'],
        $data['billing_address']
    );
    
    $stmt->execute();
    $order_id = $conn->insert_id;
    $stmt->close();

    // Process payment if not COD
    if ($payment_method !== 'cod') {
        // In a real app, integrate with payment gateway here
        // For now, just simulate successful payment
        $payment_success = true;
        
        if (!$payment_success) {
            throw new Exception("Payment processing failed");
        }
    }

    // Commit transaction
    $conn->commit();

    // Return success response
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'order_id' => $order_id,
        'message' => 'Order placed successfully'
    ]);

} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
