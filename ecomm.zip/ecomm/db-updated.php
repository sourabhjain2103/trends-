<?php
$host = 'localhost';
$db = 'ecommerce';
$user = 'root';
$pass = 'kashinaresh19#';

try {
    $conn = new mysqli($host, $user, $pass, $db);
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    
    // Define constants for table names
    define('USERS_TABLE', 'users');
    define('ORDERS_TABLE', 'orders');
    define('PRODUCTS_TABLE', 'products');
    
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
    header("Location: error.php?code=db");
    exit();
}
?>
