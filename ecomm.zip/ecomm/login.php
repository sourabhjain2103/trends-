<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'db-updated.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        if (empty($username) || empty($password)) {
            throw new Exception('Username and password are required');
        }

        $stmt = $conn->prepare("SELECT * FROM " . USERS_TABLE . " WHERE username = ?");
        if (!$stmt) {
            throw new Exception('Database error: ' . $conn->error);
        }
        
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            throw new Exception('Invalid credentials');
        }

        $user = $result->fetch_assoc();
        if (!password_verify($password, $user['password'])) {
            throw new Exception('Invalid credentials');
        }

        // Regenerate session ID to prevent fixation
        session_regenerate_id(true);
        
        $_SESSION = [
            'user_id' => $user['id'],
            'username' => $user['username'],
            'logged_in' => true,
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT']
        ];

        echo json_encode([
            'message' => 'Login successful',
            'user' => [
                'id' => $user['id'],
                'username' => $user['username']
            ]
        ]);

    } catch (Exception $e) {
        http_response_code(401);
        echo json_encode(['message' => $e->getMessage()]);
    } finally {
        if (isset($stmt)) $stmt->close();
        $conn->close();
    }
}
?>
